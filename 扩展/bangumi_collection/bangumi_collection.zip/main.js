// Initialize state
const state = _state;
state.username = state.username || 'lpwcnm'; // Default user
state.defaultTags = state.defaultTags || 'Bangumi';
state.collectionList = state.collectionList || [];
state.loading = false;

function getStatusText(type) {
  switch (type) {
    case 1: return '想看';
    case 2: return '看过';
    case 3: return '在看';
    case 4: return '搁置';
    case 5: return '抛弃';
    default: return '未知';
  }
}

// Fetch collections from Bangumi API
async function fetchCollections() {
  if (state.loading) return;
  
  const username = state.username ? state.username.trim() : '';
  if (!username) {
    await essenmelia.showSnackBar('请输入用户名');
    return;
  }

  state.loading = true;
  // Show loading indicator
  state.collectionList = [{
    type: 'container',
    props: { height: 100, padding: 20 },
    children: [{
      type: 'text', 
      props: { text: '加载中...', textAlign: 'center' }
    }]
  }];

  try {
    const url = `https://api.bgm.tv/v0/users/${username}/collections`;
    console.log('Fetching collections from: ' + url);
    const resStr = await essenmelia.httpGet(url, {});
    console.log('Response received, length: ' + (resStr ? resStr.length : 'null'));
    
    // Check if resStr is already an object (auto-parsed by bridge?)
    let res;
    if (typeof resStr === 'object') {
      res = resStr;
      console.log('Response is already an object');
    } else {
      res = JSON.parse(resStr);
      console.log('JSON parsed successfully');
    }
    
    if (res && res.data) {
      const items = res.data;
      const newUiList = [];

      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        const subject = item.subject || {};
        const images = subject.images || {};
        const cover = images.common || images.medium || images.large || '';
        
        // Build UI component for each item
        const card = {
          type: 'card',
          props: {
            variant: 'filled',
            margin: [0, 0, 0, 12],
            padding: 0
          },
          children: [{
            type: 'row',
            props: {
              crossAxisAlignment: 'start'
            },
            children: [
              // Cover Image
              {
                type: 'image',
                props: {
                  url: cover,
                  width: 80,
                  height: 120,
                  fit: 'cover',
                  borderRadius: 12
                }
              },
              // Info Column
              {
                type: 'expanded',
                children: [{
                  type: 'column',
                  props: {
                    padding: [12, 8, 12, 8],
                    crossAxisAlignment: 'start'
                  },
                  children: [
                    // Title
                    {
                      type: 'text',
                      props: {
                        text: subject.name_cn || subject.name,
                        style: 'titleMedium',
                        maxLines: 1,
                        bold: true
                      }
                    },
                    // Subtitle (Original Name)
                    {
                      type: 'text',
                      props: {
                        text: subject.name,
                        style: 'bodySmall',
                        maxLines: 1,
                        textColor: 'outline'
                      }
                    },
                    // Summary (if available)
                    subject.short_summary ? {
                      type: 'text',
                      props: {
                        text: subject.short_summary,
                        style: 'bodySmall',
                        maxLines: 2,
                        textColor: 'onSurfaceVariant',
                        padding: [0, 4, 0, 4]
                      }
                    } : { type: 'sized_box', props: { height: 4 } },
                    // Status/Score Row
                    {
                      type: 'row',
                      props: {
                        padding: [0, 4, 0, 0]
                      },
                      children: [
                        // Status Badge
                        {
                          type: 'container',
                          props: {
                            color: 'secondaryContainer',
                            padding: [6, 2, 6, 2],
                            borderRadius: 4,
                            margin: [0, 8, 0, 0]
                          },
                          children: [{
                            type: 'text',
                            props: {
                              text: getStatusText(item.type),
                              style: 'labelSmall',
                              textColor: 'onSecondaryContainer'
                            }
                          }]
                        },
                        // User Rating
                        item.rate > 0 ? {
                          type: 'container',
                          props: {
                            color: 'primaryContainer',
                            padding: [6, 2, 6, 2],
                            borderRadius: 4,
                            margin: [0, 8, 0, 0]
                          },
                          children: [{
                            type: 'text',
                            props: {
                              text: '评分: ' + item.rate,
                              style: 'labelSmall',
                              textColor: 'onPrimaryContainer'
                            }
                          }]
                        } : { type: 'sized_box' },
                         // Global Score
                         {
                          type: 'container',
                          props: {
                            color: 'surfaceContainerHighest',
                            padding: [6, 2, 6, 2],
                            borderRadius: 4
                          },
                          children: [{
                            type: 'text',
                            props: {
                              text: '均分: ' + (subject.score || '-'),
                              style: 'labelSmall',
                              textColor: 'onSurfaceVariant'
                            }
                          }]
                        }
                      ]
                    },
                    // Add to Event Button
                    {
                        type: 'row',
                        props: {
                            mainAxisAlignment: 'end',
                            padding: [0, 8, 0, 0]
                        },
                        children: [{
                            type: 'button',
                            props: {
                                label: '导入日程',
                                icon: 0xe145, // add
                                variant: 'tonal',
                                onTap: 'addToEvent?title=' + encodeURIComponent(subject.name_cn || subject.name) + '&cover=' + encodeURIComponent(cover)
                            }
                        }]
                    }
                  ]
                }]
              }
            ]
          }]
        };
        newUiList.push(card);
      }
      
      state.collectionList = newUiList;
    } else {
      state.collectionList = [{
        type: 'text',
        props: { text: '未找到数据', textAlign: 'center', padding: 20 }
      }];
    }
  } catch (e) {
    console.log('Error fetching collections', e);
    await essenmelia.showSnackBar('加载失败: ' + e);
    state.collectionList = [{
      type: 'text',
      props: { text: '加载失败: ' + e, textColor: 'error', textAlign: 'center', padding: 20 }
    }];
  }

  state.loading = false;
}

async function addToEvent(args) {
  const title = args.title;
  const cover = args.cover;
  
  // Parse tags
  let tags = ['Bangumi'];
  if (state.defaultTags) {
      const extraTags = state.defaultTags.split(/[,，]/).map(t => t.trim()).filter(t => t.length > 0);
      tags = tags.concat(extraTags);
  }

  try {
    await essenmelia.addEvent({
      title: '追番: ' + title,
      description: `Cover: ${cover}\nFrom Bangumi Collection Extension`,
      tags: tags,
      imageUrl: cover
    });
    await essenmelia.showSnackBar('已添加到日程: ' + title);
  } catch (e) {
    await essenmelia.showSnackBar('添加失败: ' + e);
  }
}

// Lifecycle hook
function onLoad() {
  console.log('Bangumi Collection extension loaded');
  return { status: 'loaded' };
}
